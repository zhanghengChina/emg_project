#include "ros/ros.h"
//下面是关于moveit的头文件
#include "moveit/move_group_interface/move_group.h"
#include "moveit/robot_model_loader/robot_model_loader.h"
#include "moveit/robot_model/robot_model.h"
#include "moveit/robot_state/robot_state.h"
#include "moveit/planning_scene_interface/planning_scene_interface.h"
#include "moveit_msgs/DisplayTrajectory.h"
//下面是关于action的头文件
#include "actionlib/client/simple_action_client.h"
#include "control_msgs/FollowJointTrajectoryAction.h"

using namespace std;

typedef actionlib::SimpleActionClient<control_msgs::FollowJointTrajectoryAction> Client;

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "move_robot_by_action");
    ros::NodeHandle nh;

    Client ac("follow_joint_trajectory", true);  
    ROS_INFO("Waiting for action server to start.");  
    ac.waitForServer();  
    ROS_INFO("Action server started, sending trajectory.");  
    control_msgs::FollowJointTrajectoryGoal goal;



    trajectory_msgs::JointTrajectoryPoint points;
    std::vector<double> position;
    position.push_back(3.142742156982422);
    position.push_back(0.012825727462768555);
    position.push_back(-2.901377026234762);
    position.push_back(-1.7457740942584437);
    position.push_back(-0.01794433780014515);
    position.push_back(-0.0002515951739709976);
    points.positions = position;
    points.time_from_start = ros::Duration(5);
    goal.trajectory.points.push_back(points);

    trajectory_msgs::JointTrajectoryPoint points2;
    position.clear();
    position.push_back(0);
    position.push_back(0);
    position.push_back(0);
    position.push_back(0);
    position.push_back(0);
    position.push_back(0);
    points2.positions = position;
    points2.time_from_start = ros::Duration(10);
    goal.trajectory.points.push_back(points2);


    goal.trajectory.header.stamp = ros::Time::now();
    goal.trajectory.header.frame_id = "base_link";
    std::vector<std::string> joint_names;
    nh.getParam("controller_joint_names",joint_names);
    goal.trajectory.joint_names = joint_names;

    ac.sendGoal(goal);
    ac.waitForResult(ros::Duration(10));

    ROS_INFO("you are in the last line");
    return 0;
}


